package machine;

abstract class Drink {
   /*  private int water;
    private int milk;
    private int cbeans;
     private float price;

    public int getWater() {
        return water;
    }

    public void setWater(int water) {
        this.water = water;
    }

    public int getMilk() {
        return milk;
    }

    public void setMilk(int milk) {
        this.milk = milk;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getCbeans() {
        return cbeans;
    }

    public void setCbeans(int cbeans) {
        this.cbeans = cbeans;
    }*/
}
